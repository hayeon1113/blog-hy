package com.springboot.hobbyverse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HyProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
