package com.springboot.hayeonproj.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.springboot.hayeonproj.model.Category;
import com.springboot.hayeonproj.model.Post;

@Mapper
public interface PostMapper {
	void updatePostCount(Integer c_id);
	Integer getPostCount(Integer c_id);
	Integer getPostTotal();
	Category getCategoryById(Integer c_id);
	Post getPostDetail(Integer p_id);
	List<Post> getPostList();
	List<Post> getPostListByCategory(Integer c_id);
	List<Post> getPost(Integer c_id);
	List<Category> getCategory();
	void putPost(Post post);
}
