package com.springboot.hayeonproj.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Category {
	@Id
	private Integer c_id;
	private String c_name;
	
	@OneToMany(mappedBy = "category")
    private List<Post> posts;
	
	private Integer postCount;
}
