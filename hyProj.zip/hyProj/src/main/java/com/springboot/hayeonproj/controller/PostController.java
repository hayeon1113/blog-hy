package com.springboot.hayeonproj.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.hayeonproj.model.Category;
import com.springboot.hayeonproj.model.Post;
import com.springboot.hayeonproj.service.PostService;

@Controller
public class PostController {
    @Autowired
    private PostService postService;
    
    @GetMapping("/postDetail")
    public ModelAndView postDetail(Integer p_id, Integer c_id) {
    	ModelAndView mav = new ModelAndView("detail");
    	Post post = this.postService.getPostDetail(p_id);
    	Category category = this.postService.getCategoryById(post.getC_id());
        Integer postCount = this.postService.getPostCount(c_id); // 게시글 수
    	mav.addObject("postCount", postCount);
    	mav.addObject("category", category);
    	mav.addObject("post", post);
    	return mav;
    }
    
    @GetMapping("/postList")
    public ModelAndView postList(Integer c_id) {
        ModelAndView mav = new ModelAndView("category");

        // postList를 가져옴
        List<Post> postList = postService.getPostList();
        System.out.println("🔍 [PostController] postList: " + postList); // 콘솔 로그 추가

        // 카테고리 목록 조회
        List<Category> category = postService.getCategory();
        
        // 전체 게시글 수 및 특정 카테고리 게시글 수 조회
        Integer totalCount = postService.getPostTotal();
        Integer postCount = postService.getPostCount(c_id);

        // Model에 데이터 추가
        mav.addObject("totalCount", totalCount);
        mav.addObject("postCount", postCount);
        mav.addObject("category", category);
        mav.addObject("postList", postList);

        return mav;
    }
    
    @GetMapping("/writePost")
    public ModelAndView writePost(Post post) {
    	ModelAndView mav = new ModelAndView("category");
    	List<Category> categoryList = this.postService.getCategory();
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDate = dateFormat.format(new Date());
        mav.addObject("BODY", "writePost.jsp");
    	mav.addObject(new Post());
    	mav.addObject("currentDate", currentDate);
    	mav.addObject("categoryList", categoryList);
    	return mav;
    }
    @PostMapping("/writePostDo")
    public ModelAndView writePostDo(Post post) {
    	ModelAndView mav = new ModelAndView();
    	this.postService.putPost(post);
    	mav.setViewName("writePostDone"); //alert
    	mav.addObject("message","게시글이 등록되었습니다.");
    	return mav;
    }
    
    //카테고리별 목록
    @GetMapping("/grammer")
    public ModelAndView grammerPost(Integer c_id) {
        ModelAndView mav = new ModelAndView("category");
        List<Post> postList = this.postService.getPost(c_id);
        List<Category> category = this.postService.getCategory();
        mav.addObject("BODY", "p_grammer.jsp");
        mav.addObject("category", category);
        mav.addObject("postList", postList);
        return mav;
    }
    @GetMapping("/backend")
    public ModelAndView backendPost(Integer c_id) {
        ModelAndView mav = new ModelAndView("category");
        List<Post> postList = this.postService.getPost(c_id);
        List<Category> category = this.postService.getCategory();
        mav.addObject("BODY", "p_backend.jsp");
        mav.addObject("category", category);
        mav.addObject("postList", postList);
        return mav;
    }
    @GetMapping("/frontend")
    public ModelAndView frontendPost(Integer c_id) {
        ModelAndView mav = new ModelAndView("category");
        List<Post> postList = this.postService.getPost(c_id);
        List<Category> category = this.postService.getCategory();
        mav.addObject("BODY", "p_frontend.jsp");
        mav.addObject("category", category);
        mav.addObject("postList", postList);
        return mav;
    }
    @GetMapping("/git")
    public ModelAndView gitPost(Integer c_id) {
        ModelAndView mav = new ModelAndView("category");
        List<Post> postList = this.postService.getPost(c_id);
        List<Category> category = this.postService.getCategory();
        mav.addObject("BODY", "p_git.jsp");
        mav.addObject("category", category);
        mav.addObject("postList", postList);
        return mav;
    }
    @GetMapping("/planner")
    public ModelAndView plannerPost(Integer c_id) {
        ModelAndView mav = new ModelAndView("category");
        List<Post> postList = this.postService.getPost(c_id);
        List<Category> category = this.postService.getCategory();
        mav.addObject("BODY", "p_planner.jsp");
        mav.addObject("category", category);
        mav.addObject("postList", postList);
        return mav;
    }
    @GetMapping("/projects")
    public ModelAndView projectsPost(Integer c_id) {
        ModelAndView mav = new ModelAndView("category");
        List<Post> postList = this.postService.getPost(c_id);
        List<Category> category = this.postService.getCategory();
        mav.addObject("BODY", "p_projects.jsp");
        mav.addObject("category", category);
        mav.addObject("postList", postList);
        return mav;
    }
}
