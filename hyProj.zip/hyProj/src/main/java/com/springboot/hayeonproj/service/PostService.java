package com.springboot.hayeonproj.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.hayeonproj.mapper.PostMapper;
import com.springboot.hayeonproj.model.Category;
import com.springboot.hayeonproj.model.Post;

@Service
public class PostService {
    @Autowired
    private PostMapper postMapper;

    public void updatePostCount(Integer c_id) {
    	this.postMapper.updatePostCount(c_id);
    }
	public Integer getPostCount(Integer c_id) {
		return this.postMapper.getPostCount(c_id);
	}
	public Integer getPostTotal() {
		return this.postMapper.getPostTotal();
	}
    
    public Category getCategoryById(Integer c_id) {
    	return this.postMapper.getCategoryById(c_id);
    }
    public Post getPostDetail(Integer p_id){
    	return this.postMapper.getPostDetail(p_id);
    }
    
    public List<Post> getPostList() {
        List<Post> postList = this.postMapper.getPostList();
        System.out.println("Post List: " + postList);  // 데이터 확인 로그
        return postList;
    }
    public List<Post> getPostListByCategory(Integer c_id) {
        return postMapper.getPostListByCategory(c_id);
    }
    public List<Post> getPost(Integer c_id) {
    	return this.postMapper.getPost(c_id);
    }

    public List<Category> getCategory() {
        return this.postMapper.getCategory();
    }
    
    public void putPost(Post post) {
    	this.postMapper.putPost(post);
    }
}
