package com.springboot.hayeonproj.model;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Transient;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer p_id;  // 자동 증가 필드
    private Integer c_id;  // 외래 키
    @ManyToOne
    @JoinColumn(name = "c_id", insertable = false, updatable = false) // c_id와 외래 키 관계 설정
    private Category category;
    private String title;
    private String sub_title;
    private String info;
    @CreationTimestamp
    @Column(updatable = false)
    private Timestamp w_date;  // 생성 날짜
    @Transient
    private String c_name;
}
